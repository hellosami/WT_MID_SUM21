<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

</head>

<body>

    <table>
        <tr>
            <td>Admin Panel | </td>
            <td>Welcome, <?php echo $_POST['username']; ?></td>
        </tr>
    </table>
    <hr>
        <ul>
            <li><a href="user_ban.php">User Ban</a></li>
            <li><a href="add_new_coupon.php">Add New Coupon</a></li>
            <li><a href="offer_creation.php">Make Offer</a></li>

        </ul>
        
       
     
     

    <hr>
</body>
</html>
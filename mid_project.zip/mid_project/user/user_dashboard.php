<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

</head>

<body>
    <h1>Welcome, <?php echo $_POST['username']; ?></h1>
    <hr>
        <ul>
            <li>Posts
                <ul>
                    <li><a href="post/vehicle_rant_post.php">Post Vehicle</a></li>
                    <li><a href="post/apartment.php">Post Apartment</a></li>
                    <li><a href="post/instrument_post.php">Post Instrument</a></li>
            
                </ul>
            </li>
            <br>
            <li><a href="profile_update.php">Profile Update</a></li>
            <li><a href="rent_request_form.php">Request Rent</a></li>
            <li><a href="payment/payment.php">Payment</a></li>
            <li><a href="support.php">Support</a></li>
            <li><a href="feedback.php">Feedback</a></li>
            <li><a href="setting.php">Settings</a></li>
        </ul>
        
       
     
     

    <hr>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    
</head>
<body>
    <h1>Payment</h1>

    <ul>
        <li><a href="pf_bkash.php">Bkash</li>
        <li><a href="pf_cc.php">Credit Card</li>
    </ul>
</body>
</html>
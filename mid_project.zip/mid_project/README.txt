SAMI::
payment//
pf_bkash.php
pf_cc

user//
profile_update.php
rent_request_form.php

KAMRUL::
apartmentform
vehicleform
instrumentform
loginform


BORNA::
setting.php
user_ban.php
feedback.php
contact_us.php

SANZIDA ::
search
support
offer creation
add new coupon